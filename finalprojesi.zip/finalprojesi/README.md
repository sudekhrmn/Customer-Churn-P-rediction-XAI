# IBM Telco Customer Churn Analizi ve Makine Öğrenmesi Modellerinin Karşılaştırılması

Bu proje, telekomünikasyon sektöründeki müşteri kaybı (Churn) problemini öngörebilmek amacıyla **IBM Telco Customer Churn** veri seti üzerinde yürütülmüş uçtan uca bir veri madenciliği çalışmasıdır. Proje süreçleri, endüstri standardı olan **CRISP-DM** metodolojisinin 6 temel adımına sadık kalınarak yapılandırılmıştır.

Platformlar arası doğrulama amacıyla deneysel süreçler hem **Weka** hem de **Python (Scikit-Learn)** ortamlarında koşturulmuştur.---

## 👥 Proje Ekibi
* **Emre EMÜL** - Öğrenci No: 231041057
* **Sümeyra Melike ASLAN** - Öğrenci No: 231041051
* **Nisa Sude KAHRAMAN** - Öğrenci No: 231041031

**Ders Sorumlusu:** Mehmet Fatih Yüce
**Kurum:** İstanbul Gedik Üniversitesi - Bilgisayar Mühendisliği Bölümü

---

## 🗂️ Proje Klasör Yapısı

Proje teslim klasörü ve GitHub deposu aşağıdaki hiyerarşide düzenlenmiştir:

```text
proje/
├── rapor/
│   ├── rapor (1).tex        # Projenin LaTeX kaynak kodu
│   └── rapor_sablonu.docx   # Projenin Word taslak dosyası
├── python/
│   ├── PythonApplication2.py      # Veri ön işleme, model eğitimi ve test kaynak kodu
│   └── PythonApplication2.pyproj  # Visual Studio Python proje dosyası
├── veri/
│   ├── train.arff           # Weka modelleri için ayrılmış %70 eğitim veri seti
│   ├── test.arff            # Çapraz doğrulama için ayrılmış %30 test veri seti
│   └── (Deneysel Görseller ve .model Dosyaları) # Weka üzerinden alınan model çıktıları
├── veriseti/
│   └── tableConvert.com_t9lvji.csv.arff  # Ham ve orijinal IBM Telco veri seti
├── verimadenciligi.pdf      # Akademik standartlarda hazırlanmış ana sonuç raporu
└── README.md                # Proje tanıtım kılavuzu (Bu dosya)
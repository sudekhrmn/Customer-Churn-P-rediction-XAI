﻿import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

# 1. Veri Setinin Yüklenmesi
print("🔄 Python ortamında Telco Churn veri seti yükleniyor...")
df = pd.read_csv('tableConvert.com_6ip6xz.csv')

# 2. Weka'daki Veri Ön İşleme (Temizlik ve Veri Sızıntısı Engelleme)
columns_to_drop = ['CustomerID', 'Count', 'Country', 'State', 'City', 'Zip Code', 
                   'Lat Long', 'Latitude', 'Longitude', 'Churn Label', 'Churn Score', 'CLTV', 'Churn Reason']
df_clean = df.drop(columns=columns_to_drop, errors='ignore')

# 3. Eksik Verilerin Temizlenmesi (Missing Value Handling)
df_clean['Total Charges'] = pd.to_numeric(df_clean['Total Charges'], errors='coerce')
df_clean = df_clean.dropna(subset=['Total Charges'])

# 4. Kategorik Değişkenlerin Sayısallaştırılması (One-Hot Encoding)
X = df_clean.drop(columns=['Churn Value'])
y = df_clean['Churn Value']
X = pd.get_dummies(X, drop_first=True)

# 5. Verinin Bölünmesi (%80 Eğitim, %20 Test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# 6. Modellerin Tanımlanması
models = {
    "Naive Bayes": GaussianNB(),
    "Decision Tree (J48 Karşılığı)": DecisionTreeClassifier(max_depth=4, random_state=42),
    "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
    "Random Forest (Ensemble)": RandomForestClassifier(n_estimators=100, random_state=42)
}

# 7. Modellerin Eğitilmesi ve Sonuçların Basılması
print("\n🏆 --- PYTHON MODEL PERFORMANSLARI --- 🏆\n")
for name, model in models.items():
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    acc = accuracy_score(y_test, preds) * 100
    f1 = f1_score(y_test, preds, average='weighted')
    
    print(f"================ {name} ================")
    print(f"Doğruluk Oranı (Accuracy): %{acc:.2f}")
    print(f"F1-Skoru (Weighted F1): {f1:.4f}")
    print("Hata Matrisi (Confusion Matrix):")
    print(confusion_matrix(y_test, preds))
    print("\n")
